﻿
Write-Host "This is a test!"
Write-Host "Environement variable test: CUDA_DEVICE_ORDER=$($env:CUDA_DEVICE_ORDER)"
Write-Host "Press any key to create a new child or press CTRL-C to stop" -ForegroundColor Yellow
[void]($Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown'))

Write-Host "My process id is $PID"
Write-Host "My path is $(Split-Path $script:MyInvocation.MyCommand.Path)"
Write-Host "Get current data"

$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if ($currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {"I am Admin"} else {"I am User"}

$ErrorActionPreference = "Stop"
try {
    $StartCommand = Get-CimInstance Win32_Process -filter "ProcessID=$PID" | Select-Object -ExpandProperty CommandLine
    if (-not $StartCommand) {Write-Host "Error reading current data"}
    else {
        Write-Host "Starting child '$StartCommand'"
        $NewKid = Invoke-CimMethod Win32_Process -MethodName Create -Arguments @{CommandLine=$StartCommand;CurrentDirectory=(Split-Path $script:MyInvocation.MyCommand.Path)}
        if (-not $NewKid) {Write-Host "Child could not be created"}
        else {
            Sleep 1;
            if (-not $NewKid.ProcessId -or $NewKid.ReturnValue -ne 0) {Write-Host "Child creation failed with errorcode $($NewKid.ReturnValue)"}
            $NewKid
        }
    }
}
catch {
    Write-Host "Some error"
}

$Error
  