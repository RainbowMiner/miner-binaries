from . import chinese_simplified, dutch, english, esperanto, french, italian, japanese, lobjan, portuguese, russian, spanish

monero_langs = [chinese_simplified.words, dutch.words, english.words, esperanto.words, french.words, italian.words, japanese.words, lobjan.words, portuguese.words, russian.words, spanish.words]
